const router = require("express").Router();
const AWS = require("aws-sdk");

const { AWS_REGION, ACCOUNT_C_ROLE_ARN } = process.env;

AWS.config.update({ region: AWS_REGION || "us-east-1" });

const dynamodb = new AWS.DynamoDB.DocumentClient();
const sts = new AWS.STS();

/* ================= AWS HELPERS ================= */

async function assumeAccountCLogs() {
  const r = await sts.assumeRole({
    RoleArn: ACCOUNT_C_ROLE_ARN,
    RoleSessionName: "app-logs-reader"
  }).promise();

  return new AWS.CloudWatchLogs({
    region: AWS_REGION,
    accessKeyId: r.Credentials.AccessKeyId,
    secretAccessKey: r.Credentials.SecretAccessKey,
    sessionToken: r.Credentials.SessionToken
  });
}

/* ================= DB HELPERS ================= */

async function getDeployment(deploymentId) {
  const r = await dynamodb.get({
    TableName: "Deployments",
    Key: { deploymentId }
  }).promise();

  return r.Item;
}

/* ================= ROUTE ================= */

router.get("/app-logs/:deploymentId", async (req, res) => {
  try {
    const { deploymentId } = req.params;
    const limit = Number(req.query.limit) || 100;

    const deployment = await getDeployment(deploymentId);
    if (!deployment) {
      return res.status(404).json({ error: "Deployment not found" });
    }

    const logCfg = deployment.logConfig;

    if (!logCfg || logCfg.enabled === false) {
      return res.json({
        deploymentId,
        count: 0,
        events: []
      });
    }

    const { logGroup, logStreamPrefix } = logCfg.cloudwatch || {};

    if (!logGroup) {
      return res.status(400).json({ error: "Log group not configured for deployment" });
    }

    const logs = await assumeAccountCLogs();

    const params = {
      logGroupName: logGroup,
      limit,
      startTime: Date.now() - 1000 * 60 * 60 // last 1 hour
    };

    if (logStreamPrefix) {
      params.logStreamNamePrefix = logStreamPrefix;
    }

    const result = await logs.filterLogEvents(params).promise();

    res.json({
      deploymentId,
      logGroup,
      count: result.events.length,
      events: result.events
    });

  } catch (err) {
    console.error("App logs error:", err);
    res.status(500).json({ error: "Failed to fetch app logs" });
  }
});

module.exports = router;
