const router = require("express").Router();
const AWS = require("aws-sdk");

const { AWS_REGION } = process.env;

AWS.config.update({ region: AWS_REGION || "us-east-1" });
const dynamodb = new AWS.DynamoDB.DocumentClient();

/* ================= HELPERS ================= */

async function getDeployment(deploymentId) {
  const r = await dynamodb.get({
    TableName: "Deployments",
    Key: { deploymentId }
  }).promise();

  return r.Item;
}

async function updateObservability(deploymentId, data) {
  const updates = [];
  const values = {};
  const names = {};

  for (const [k, v] of Object.entries(data)) {
    if (v === undefined) continue;
    updates.push(`#${k} = :${k}`);
    values[`:${k}`] = v;
    names[`#${k}`] = k;
  }

  if (!updates.length) return;

  await dynamodb.update({
    TableName: "Deployments",
    Key: { deploymentId },
    UpdateExpression: "SET " + updates.join(", "),
    ExpressionAttributeNames: names,
    ExpressionAttributeValues: values
  }).promise();
}

/* ================= ROUTE ================= */

/**
 * Called ONLY by Jenkins after deploy
 */
router.post("/deployment/observability", async (req, res) => {
  try {
    const {
      deploymentId,
      endpointUrl,
      metricsConfig,
      logConfig
    } = req.body;

    if (!deploymentId) {
      return res.status(400).json({ error: "deploymentId required" });
    }

    const dep = await getDeployment(deploymentId);
    if (!dep) {
      return res.status(404).json({ error: "Deployment not found" });
    }

    await updateObservability(deploymentId, {
      endpointUrl,
      metricsConfig,
      logConfig
    });

    res.json({
      status: "UPDATED",
      deploymentId
    });

  } catch (err) {
    console.error("Observability update error:", err);
    res.status(500).json({ error: "Failed to update observability" });
  }
});

module.exports = router;
