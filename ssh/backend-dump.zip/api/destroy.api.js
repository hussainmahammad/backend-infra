const router = require("express").Router();
const axios = require("axios");
const AWS = require("aws-sdk");

const {
  JENKINS_URL,
  JENKINS_USER,
  JENKINS_API_TOKEN,
  AWS_REGION
} = process.env;

const auth = { username: JENKINS_USER, password: JENKINS_API_TOKEN };

AWS.config.update({ region: AWS_REGION || "us-east-1" });
const dynamodb = new AWS.DynamoDB.DocumentClient();

/* ================= HELPERS ================= */

async function getDeployment(deploymentId) {
  const r = await dynamodb.get({
    TableName: "Deployments",
    Key: { deploymentId }
  }).promise();

  return r.Item;
}

async function updateStatus(deploymentId, status, destroyed = false) {
  const updates = ["#s = :s"];
  const values = { ":s": status };
  const names = { "#s": "status" };

  if (destroyed) {
    updates.push("destroyedAt = :t");
    values[":t"] = new Date().toISOString();
  }

  await dynamodb.update({
    TableName: "Deployments",
    Key: { deploymentId },
    UpdateExpression: "SET " + updates.join(", "),
    ExpressionAttributeNames: names,
    ExpressionAttributeValues: values
  }).promise();
}

function wait(ms) {
  return new Promise(r => setTimeout(r, ms));
}

async function watchDestroy({ jobName, buildNumber, deploymentId }) {
  while (true) {
    const r = await axios.get(
      `${JENKINS_URL}/job/${jobName}/${buildNumber}/api/json`,
      { auth }
    );

    if (!r.data.building) {
      const finalStatus =
        r.data.result === "SUCCESS" ? "DESTROYED" : "FAILED";

      // 🔓 This UNBLOCKS future deploys
      await updateStatus(deploymentId, finalStatus, true);
      break;
    }

    await wait(5000);
  }
}

/* ================= ROUTE ================= */

router.post("/destroy", async (req, res) => {
  try {
    const { deploymentId } = req.body;

    if (!deploymentId) {
      return res.status(400).json({ error: "deploymentId required" });
    }

    const dep = await getDeployment(deploymentId);
    if (!dep) {
      return res.status(404).json({ error: "Deployment not found" });
    }

    // ✅ Idempotent destroy
    if (dep.status === "DESTROYED" || dep.destroyedAt) {
      return res.json({
        deploymentId,
        status: "ALREADY_DESTROYED"
      });
    }

    // ❌ Prevent double-destroy
    if (dep.status === "DESTROYING") {
      return res.json({
        deploymentId,
        status: "ALREADY_DESTROYING"
      });
    }

    // 🔒 Only allow destroy from valid states
    if (!["RUNNING", "FAILED"].includes(dep.status)) {
      return res.status(409).json({
        error: `Cannot destroy deployment in ${dep.status} state`
      });
    }

    // Mark DESTROYING immediately (prevents deploy)
    await updateStatus(dep.deploymentId, "DESTROYING");

    // Trigger Jenkins destroy job
    const trigger = await axios.post(
      `${JENKINS_URL}/job/${dep.destroyJob}/buildWithParameters`,
      {
        appId: dep.appId,
        runtime: dep.runtime,
        deploymentId: dep.deploymentId
      },
      { auth }
    );

    // Resolve Jenkins build number
    const queueUrl = trigger.headers.location;
    let buildNumber;

    while (!buildNumber) {
      const q = await axios.get(`${queueUrl}api/json`, { auth });
      buildNumber = q.data.executable?.number;
      if (!buildNumber) await wait(1000);
    }

    watchDestroy({
      jobName: dep.destroyJob,
      buildNumber,
      deploymentId: dep.deploymentId
    });

    res.json({
      deploymentId: dep.deploymentId,
      status: "DESTROYING"
    });

  } catch (err) {
    console.error("Destroy error:", err);
    res.status(500).json({ error: "Failed to destroy" });
  }
});

module.exports = router;
