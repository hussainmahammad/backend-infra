const router = require("express").Router();
const axios = require("axios");
const AWS = require("aws-sdk");
const { watchDeployment } = require("../workers/deploymentWatcher");

const {
  JENKINS_URL,
  JENKINS_USER,
  JENKINS_API_TOKEN,
  AWS_REGION
} = process.env;

const auth = { username: JENKINS_USER, password: JENKINS_API_TOKEN };

AWS.config.update({ region: AWS_REGION || "us-east-1" });
const dynamodb = new AWS.DynamoDB.DocumentClient();

/* ================= SAFE UPDATE ================= */

async function updateDeploymentRuntime(deploymentId, data) {
  const updates = [];
  const values = {};
  const names = {};

  for (const [k, v] of Object.entries(data)) {
    if (v === undefined) continue;
    updates.push(`#${k} = :${k}`);
    values[`:${k}`] = v;
    names[`#${k}`] = k;
  }

  if (!updates.length) return;

  await dynamodb.update({
    TableName: "Deployments",
    Key: { deploymentId },
    UpdateExpression: "SET " + updates.join(", "),
    ExpressionAttributeNames: names,
    ExpressionAttributeValues: values
  }).promise();
}

/* ================= HELPERS ================= */

async function getApplication(appId) {
  const r = await dynamodb.get({
    TableName: "Applications",
    Key: { appId }
  }).promise();
  return r.Item;
}

/**
 * Enforce: ONLY ONE ACTIVE DEPLOYMENT PER APP
 */
async function getActiveDeployment(appId) {
  const r = await dynamodb.scan({
    TableName: "Deployments",
    FilterExpression:
      "appId = :a AND #s IN (:d, :r, :x)",
    ExpressionAttributeNames: {
      "#s": "status"
    },
    ExpressionAttributeValues: {
      ":a": appId,
      ":d": "DEPLOYING",
      ":r": "RUNNING",
      ":x": "DESTROYING"
    }
  }).promise();

  return r.Items?.[0] || null;
}

async function getBuildNumberFromQueue(queueUrl) {
  while (true) {
    const r = await axios.get(`${queueUrl}api/json`, { auth });
    if (r.data.executable?.number) return r.data.executable.number;
    await new Promise(r => setTimeout(r, 1000));
  }
}

/* ================= ROUTE ================= */

router.post("/deploy", async (req, res) => {
  try {
    const { appId, runtime } = req.body;

    if (!appId) {
      return res.status(400).json({ error: "appId required" });
    }

    if (!runtime) {
      return res.status(400).json({ error: "runtime required" });
    }

    const app = await getApplication(appId);
    if (!app) {
      return res.status(404).json({ error: "App not found" });
    }

    if (!app.supportedRuntimes.includes(runtime)) {
      return res.status(400).json({
        error: `Runtime ${runtime} not supported for this app`
      });
    }

    // 🔒 BLOCK if app already has active deployment
    const active = await getActiveDeployment(appId);
    if (active) {
      return res.status(409).json({
        error: "Application already has an active deployment",
        deploymentId: active.deploymentId,
        status: active.status
      });
    }

    const { deployJobName: deployJob, destroyJobName: destroyJob } = app;

    // Trigger Jenkins with runtime parameter
    const trigger = await axios.post(
      `${JENKINS_URL}/job/${deployJob}/buildWithParameters`,
      { runtime, appId },
      { auth }
    );

    const buildNumber = await getBuildNumberFromQueue(trigger.headers.location);
    const deploymentId = `dep-${Date.now()}`;

    // Initialize deployment record
    await dynamodb.put({
      TableName: "Deployments",
      Item: {
        deploymentId,
        appId,
        runtime,

        deployJob,
        destroyJob,
        buildNumber,

        status: "DEPLOYING",

        endpointUrl: null,

        logConfig: {
          enabled: true,
          cloudwatch: {
            logGroup: `/apps/${appId}/${deploymentId}`
          }
        },

        metricsConfig:
          runtime === "eks-fargate"
            ? { enabled: false }
            : runtime === "ec2"
              ? { enabled: true, type: "ec2" }
              : { enabled: true, type: "eks" },

        createdAt: new Date().toISOString()
      }
    }).promise();

    watchDeployment({
      deploymentId,
      jobName: deployJob,
      buildNumber,
      updateDeployment: updateDeploymentRuntime
    });

    res.json({
      deploymentId,
      appId,
      runtime,
      deployJob,
      destroyJob,
      buildNumber
    });

  } catch (err) {
    console.error("Deploy failed:", err);
    res.status(500).json({ error: "Deploy failed" });
  }
});

module.exports = router;
