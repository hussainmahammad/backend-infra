const axios = require("axios");

const {
  JENKINS_URL,
  JENKINS_USER,
  JENKINS_API_TOKEN,
  BACKEND_BASE_URL
} = process.env;

const auth = { username: JENKINS_USER, password: JENKINS_API_TOKEN };

function wait(ms) {
  return new Promise(r => setTimeout(r, ms));
}

/**
 * Watches Jenkins deploy job and updates deployment status.
 * Jenkins is responsible for calling /deployment/observability
 * with endpointUrl, metricsConfig and logConfig.
 */
async function watchDeployment({
  deploymentId,
  jobName,
  buildNumber,
  updateDeployment
}) {
  console.log("Deployment watcher started:", deploymentId);

  while (true) {
    try {
      const r = await axios.get(
        `${JENKINS_URL}/job/${jobName}/${buildNumber}/api/json`,
        { auth }
      );

      if (!r.data.building) {
        const finalStatus =
          r.data.result === "SUCCESS" ? "RUNNING" : "FAILED";

        // ✅ Only update STATUS here
        await updateDeployment(deploymentId, {
          status: finalStatus,
          completedAt: new Date().toISOString()
        });

        console.log(
          `Deployment ${deploymentId} completed with status ${finalStatus}`
        );

        break;
      }

    } catch (err) {
      console.error("Deployment watcher error:", err.message);
    }

    await wait(10000);
  }
}

module.exports = { watchDeployment };
