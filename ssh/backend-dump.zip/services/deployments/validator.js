const RUNTIME = require('./runtime');

function validateDeployment(deployment) {
  if (!deployment.deploymentId) throw new Error('Missing deploymentId');
  if (!deployment.appId) throw new Error('Missing appId');

  if (!Object.values(RUNTIME).includes(deployment.runtime)) {
    throw new Error(`Unsupported runtime ${deployment.runtime}`);
  }

  if (!deployment.logConfig?.logGroup) {
    throw new Error('logConfig.logGroup is required');
  }

  // metricsConfig is OPTIONAL (null allowed)
  return true;
}

module.exports = { validateDeployment };
