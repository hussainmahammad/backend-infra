module.exports = {
  EC2: 'ec2',
  EKS_EC2: 'eks-ec2',
  EKS_FARGATE: 'eks-fargate'
};
