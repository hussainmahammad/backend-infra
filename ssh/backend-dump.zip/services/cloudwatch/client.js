const AWS = require('aws-sdk');

const cloudwatch = new AWS.CloudWatch({
  region: process.env.AWS_REGION
});

const logs = new AWS.CloudWatchLogs({
  region: process.env.AWS_REGION
});

module.exports = { cloudwatch, logs };
