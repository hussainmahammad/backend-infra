const { logs } = require('./client');

async function getLogs(logGroup) {
  return [];
}

module.exports = { getLogs };
