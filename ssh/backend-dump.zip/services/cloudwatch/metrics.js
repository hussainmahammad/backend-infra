const { cloudwatch } = require('./client');

async function getEc2Metrics(instanceId) {
  // CPU + Memory
  return {
    cpu: 12.3,
    memory: 45.6
  };
}

async function getEksMetrics({ clusterName, namespace, deployment }) {
  return {
    cpu: 220,
    memory: 512
  };
}

module.exports = { getEc2Metrics, getEksMetrics };
